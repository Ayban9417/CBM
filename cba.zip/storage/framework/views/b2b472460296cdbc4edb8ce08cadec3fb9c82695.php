<?php $__env->startSection('title', "Personal accounts || CBA"); ?>

<?php $__env->startSection('breadtitle', "Personal Accounts"); ?>

<?php $__env->startSection('breadli'); ?>
<li class="breadcrumb-item active">app_accounts</li>               
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Members</h4>
                                
                                <div class="table-responsive m-t-40">
                                    <table id="myTable" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Account Name</th>
                                                <th>Phone No</th>
                                                <th>Email</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($account->name); ?></td>
                                                <td><?php echo e($account->phone); ?></td>
                                                <td><?php echo e($account->email); ?></td>
                                                <td>
                                                <button  data-toggle="modal" data-target="#daModal<?php echo e($account->id); ?>" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i></button>
                                               
                                                </td>
                                            </tr>

                                            <!-- modal -->
                    <div id="daModal<?php echo e($account->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Edit Account</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <form method="post" action="/app-accounts/<?php echo e($account->id); ?>">
                                            <div class="modal-body">
                                                
                                                        <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Account Name:</label>
                                                        <input type="text" class="form-control" name="name" value="<?php echo e($account->name); ?>" >
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Phone Number</label>
                                                        <input type="text" class="form-control" name="phone" id="recipient-name" value="<?php echo e($account->phone); ?>">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Email</label>
                                                        <input type="text" class="form-control" name="email" id="recipient-name" value="<?php echo e($account->email); ?>">
                                                    </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success waves-effect waves-light">Update</button>
                                             
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                 <div id="delete<?php echo e($account->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Edit Account</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <form method="get" action="/app-accounts/<?php echo e($account->id); ?>">
                                            <div class="modal-body">
                                                
                                                        <?php echo csrf_field(); ?>

                                                    <div class="alert alert-danger" role="alert">
                                                        Are you sure you want to delete <?php echo e($account->name); ?>?
                                                    </div>
                                                 
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-danger waves-effect waves-light">Delete</button>
                                             
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                       
                        <div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4 class="modal-title">Add New Account</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            </div>
                                            <form method="post" action="/app-accounts">
                                            <div class="modal-body">
                                                
                                                        <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Account Name:</label>
                                                        <input type="text" class="form-control" name="name" >
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Phone Number</label>
                                                        <input type="text" class="form-control" name="phone" id="recipient-name" >
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="recipient-name" class="control-label">Email</label>
                                                        <input type="text" class="form-control" name="email" id="recipient-name" >
                                                    </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-success waves-effect waves-light">Submit</button>
                                             
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CBM\resources\views/app_accounts.blade.php ENDPATH**/ ?>